package Simple_Email_Project;

import java.util.Scanner;

class Email
     {
           private String firstName;
           private String lastName;
           private String password;
           private String email;
           private int mailboxCapacity=500;
           private int defaultPasswordLength=10;
           private String alternateEmail;
         // private String companySuffix ="aeycompany.com";
          

          //Constructor to receive the first name and last name 
           
          public Email(String firstName,String lastName){
          this.firstName=firstName;
          this.lastName=lastName;
          System.out.println("EMAIL CREATED : " + this.firstName + " " + this.lastName);


          //call a method that returns a random password
           this.password=randomPassword(defaultPasswordLength);
           System.out.println("Your password is:"+this.password);

         //combine elements to generate email
         email=firstName.toLowerCase()+lastName.toLowerCase()+"@gmail.com";
         System.out.println("Your mail is:" +email);
}
            public Email(int mailboxCapacity2) {      
}
	
         //Generate a random password
          private String randomPassword(int length){
         String passwordset="abcdefghijklmnopqrstuvwxyz123456789!@#$%";
         char[] password =new char[length]; 
          for (int i=0;i<length;i++)
       {
         int rand=(int) (Math.random() * passwordset.length());
         password[i] = passwordset.charAt(rand);
        
     }
        return new String(password);
   }

       //set the mailbox capacity
       public void setMailboxCapacity(int capacity)
    {
       this.mailboxCapacity=capacity;
       
     }
     //set the alternate email
       public void SetAlternateEmail(String altEmail)
 {
      this.alternateEmail=altEmail;
 }

      //change the password
       public void changePassword(String password)
      {
       this.password=password;
      }
       public int getMailboxCapacity()
     {
       return mailboxCapacity;}
       public String getAlternateEmail()
    {
      return alternateEmail;}
      public String getPassword()
    {
      return password;}
      public String showInfo(){
      return "DISPLAY NAME:"+firstName+" "+lastName+"\nCOMPANY Email:" +email+"\nMAILBOX CAPACITY:"+mailboxCapacity+"mb";

    } 
		
	
}
       
		
public class EmailApp {
      
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		while (true) {
			System.out.println("**** Hello,WELCOME...****");
			System.out.println("!!>>>>To CREATE A MAIL ACCOUNT>>>>!!");
			System.out.println("====================================");
			System .out.println("Choose Accout Type");
			System.out.println("1.For Myself");
			System.out.println("2.To manage a business");
			System.out.println("3.Exit");
			System.out.println("Enter your choice");
			
			int choice =sc.nextInt();
			sc.nextLine();
			
			switch (choice) {
			case 1:
				System.out.println("Enter first name");
				String firstName=sc.next();
				System.out.println("Enter last name");
				String lastName=sc.next();
				System.out.println("Enter your mailboxCapacity");
				int mailboxCapacity=sc.nextInt();
				Email em=new Email(firstName,lastName);
				
				em.setMailboxCapacity(mailboxCapacity);
				em.getPassword();
				
				System.out.println(em.showInfo());
				break;
				
			case 2:
				System.out.println("Enter first name");
				String first_Name=sc.next();
				System.out.println("Enter last name");
				String last_Name=sc.next();
				System.out.println("Enter your mailboxCapacity");
				int mailbox_Capacity=sc.nextInt();
				Email em1=new Email(first_Name,last_Name);
				
				em1.setMailboxCapacity(mailbox_Capacity);
				em1.getPassword();
				
				System.out.println(em1.showInfo());
				break;
				
			case 3:
				System.out.println("Exiting.....!");
				return;
				default:
			    System.out.println("Invalid choice");
			    
	

				
					
					}

                }
      }
}
